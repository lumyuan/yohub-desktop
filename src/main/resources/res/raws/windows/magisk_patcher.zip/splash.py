import pyi_splash

pyi_splash.update_text('Loading...')

pyi_splash.close()